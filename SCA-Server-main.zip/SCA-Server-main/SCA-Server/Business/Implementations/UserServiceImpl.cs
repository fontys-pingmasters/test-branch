using Business.Services;

namespace Business.Implementations;

public class UserServiceImpl : UserService
{
    public void CreateUser()
    {
        throw new NotImplementedException();
    }
}