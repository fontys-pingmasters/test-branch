namespace Business.Services;

public interface UserService
{
    void CreateUser();
}