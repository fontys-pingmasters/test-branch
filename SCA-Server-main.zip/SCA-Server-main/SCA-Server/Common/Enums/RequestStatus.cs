namespace Common.Enums;

public enum RequestStatus
{
    Pending,
    Accepted,
    Rejected
}