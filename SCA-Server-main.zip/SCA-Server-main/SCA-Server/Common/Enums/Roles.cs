namespace Common.Enums;

public enum Roles
{
    Admin,
    User,
    Guest,
    SuperAdmin
}