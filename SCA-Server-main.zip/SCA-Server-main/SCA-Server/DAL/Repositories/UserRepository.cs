namespace DAL.Repositories;

public class UserRepository
{
    public UserRepository(ApplicationDbContext context)
    {
        
    }
}